#ifndef amcutil_h
#define amcutil_h

template <typename T>
T amc2meter(T t) {
  return t * 0.056444;
}


#endif
